# Covariate Balancing Propensity Score (cbps): cbps_att
# This simple script uses Base R's `optim` to solve a variant of (7.10) targeting ATT weights.
# from Chapter 7 in Stefan Wager's lecture notes: http://web.stanford.edu/~swager/stats361.pdf
#
# Input:
#   X: nXp numeric covariate matrix
#   W: binary treatment assignment vector
#   intercept: whether to include an intercept in logistic model, default is TRUE.
#   theta.init: optional starting values for theta.
#   method: method argument for `optim`.
#   control control argument passed to `optim`.
#   balance.tol: if positive, the maximum pct difference in the balancing equality before convergence stops.
# Output:
#   theta.hat: estimated thetas
#   weights.0: IPW weights for control
#   weights.1: IPW weights for treated
#   convergence: optim's convergence status. 0=success.
#   balance condition: the LHS and RHS of the balance condition.

# TODOs:
# can try to automate the balance.tol convergence
# some polish, i.e. logistic start vals may sometimes be bad

cbps_att <- function(X, W,
                     intercept = TRUE,
                     theta.init = NULL,
                     method = "BFGS",
                     control = list(),
                     balance.tol = -1) {
  if (!all(W %in% c(0, 1))) {
    stop("W should be a binary vector.")
  }
  if (!is.numeric(X) || nrow(X) != length(W) || is.null(dim(X)) || anyNA(X)) {
    stop("X should be a numeric matrix with nrows = length(W).")
  }
  if (any(apply(X, 2, sd) == 0)) {
    warning("Some Xj have zero variation.", immediate. = TRUE)
  }

  .Xtheta = NULL
  .counter = 0
  .stopsignal = -1
  .trace  = control$trace
  .best.theta = NULL
  if (is.null(.trace)) {
     .trace = 10
   }
  # ATT balance constraint is:
  # 1/n1 \sum_{Wi = 0} e(x)/(1-e(x)) Xi = 1/n1 \sum_{Wi=1} Xi,
  # which gives loss function
  # (1 - W)exp(theta * X) - W * theta * X
  .objective = function(theta, X, X0, W0.idx, W1.idx, RHS) {
    if (.stopsignal == 0) {
      return (0)
    }
    .counter <<- .counter + 1
    .Xtheta <<- X %*% theta

    wts = exp(.Xtheta)[,]
    LHS = colSums(X0 * wts[W0.idx]) / length(W1.idx)
    if (intercept) {
      LHS = LHS[-1]
    }
    pct.diff = abs((RHS - LHS) / RHS)
    pct.diff.max = max(pct.diff) * 100
    if (.counter %% .trace == 0) {
      msg = paste(".objective call", .counter, "Maximum balance % difference:", pct.diff.max)
      msg2 = NULL
      if (any(is.infinite(wts[W0.idx]))) {
        msg2 = "[Warning: some control weights -> Inf, i.e. P(W|X.control) = 1]"
      } else if (all(wts[W0.idx] == 0)) {
        msg2 = "[Warning: all controls weights are 0, i.e. P(W|X.control) = 0 for all controls]"
      }
      print(paste(msg, msg2))
    }
    if (balance.tol > 0) {
      if (is.nan(pct.diff.max) || is.infinite(pct.diff.max)) {
        # if (any(is.infinite(wts[W0.idx]))) {
          # print("Warning: some control weights -> Inf, i.e. P(W|X.control) = 1")
        # } else if (all(wts[W0.idx] == 0)) {
          # print("Warning: all controls weights are 0, i.e. P(W|X.control) = 0 for all controls")
        # }
        # This can happen if P(W | X, control) = 1 in which case the ATT weights -> Inf.
        # warning(paste("Balancing failed, control weights -> Inf.",
          # "Control units with P(W|X)=1 may be problematic.",
          # "Removing these or increasing tolerance may help."))
        # .stopsignal <<- 0
        # return (0)
      } else if (pct.diff.max < balance.tol) {
        warning("Balancing acheived tolerance - stopping")
        .stopsignal <<- 0
        .best.theta <<- theta
        return (0)
      }
    }

    sum(exp(.Xtheta[W0.idx, ])) / length(W1.idx) - sum(.Xtheta[W1.idx, ]) / length(W1.idx)
  }

  .objective.gradient = function(theta, X0, Xsum1, W0.idx, n) {
    (colSums(X0 * exp(.Xtheta[W0.idx, ])) - Xsum1) / n
  }

  W1.idx = which(W == 1)
  W0.idx = which(W == 0)
  if (is.null(theta.init)) {
    # Use logistic model parameters as start values
    if (!requireNamespace("glmnet")) {
      stop("This requires the glmnet package.")
    }
    print(paste("Starting glmnet:", Sys.time()))
    glm <- glmnet::glmnet(X, W, family = "binomial", alpha = 0, lambda = 0)
    theta.init <- as.numeric(coef(glm))
    print(paste("Finished glmnet:", Sys.time()))
    if (!intercept) {
      theta.init = theta.init[-1]
    }
  }
  # X = scale(X, center = TRUE, scale = FALSE)
  if (intercept) {
    X = cbind(1, X)
  }

  X0 = X[W0.idx, ]
  Xsum1 = colSums(X[W1.idx, ])
  RHS = colSums(X[W1.idx, ]) / sum(W==1) # balance cond RHS, the treated means.
  if (intercept) {
    RHS = RHS[-1]
  }
  RHS[RHS == 0] = 0.01
  res = optim(
    par = theta.init,
    fn = function(x) .objective(x, X, X0, W0.idx, W1.idx, RHS),
    gr = function(x) .objective.gradient(x, X0, Xsum1, W0.idx, nrow(X)),
    method = method,
    lower = -Inf,
    upper = Inf,
    control = control,
    hessian = FALSE
  )

  theta.hat = res$par
  if (!is.null(.best.theta)) {
    # If optim decided to run one more iteration, store the correct optimal thetas
    theta.hat = .best.theta
  }
  weights.0 = exp(X %*% theta.hat)[,]
  if (all(abs(weights.0[W0.idx]) < 1e-10)) {
    warning("Balancing failed.")
  }
  LHS = colSums(X0 * weights.0[W0.idx]) / sum(W == 1)
  if (intercept) {
    LHS = LHS[-1]
  }

  sd.W1 = apply(X[W1.idx, ], 2, sd)
  sd.W1[sd.W1 == 0] = 1
  mean.diff = colMeans(X[W1.idx, ]) -
    apply(X0, 2, function(x) weighted.mean(x, weights.0[W0.idx]))
  balance.std = mean.diff / sd.W1
  balance.std.pre = (colMeans(X[W1.idx, ]) - colMeans(X0)) / sd.W1

  list(
    theta.hat = theta.hat,
    weights.0 = weights.0,
    weights.1 = rep(1, nrow(X)),
    convergence = res$convergence,
    balance.condition = cbind(LHS = LHS, RHS = RHS),
    balance.std = if (intercept) balance.std[-1] else balance.std,
    balance.std.pre = if (intercept) balance.std.pre[-1] else balance.std.pre
  )
}


if (FALSE) {
  set.seed(42)
  # Example with toy data
  n = 25000
  p = 50
  X.continous = matrix(rnorm(n*p), n, p) * 10 + 10
  X.binary = matrix(rbinom(n*p, 1, 0.7), n, p)
  X = cbind(X.continous, X.binary)
  W = as.integer(apply(X.continous[, 1:5] > 25, 1, any))

  # Run ATT CBPS with logistic parameter starting values = 0
  # and balance tolerance 1 %.
  system.time(res <- cbps_att(X, W,
                              theta.init = NULL,
                              control = list(trace = 10, maxit = 10000),
                              balance.tol = 1))

  head(res$balance.condition)
  plot(res$balance.std.pre)
  plot(res$balance.std)

  #  *** Some sanity checks ***
  # Simulate hard data
  n = 5000
  p = 50
  X = matrix(rnorm(n*p), n, p) * 10 + 10
  W = rbinom(n, 1, 1 / (1 + exp(20 - X[, 1])))

  res = cbps_att(X, W,
                 theta.init = rep(0, ncol(X)+1),
                 balance.tol = 35)
  head(res$balance.condition)

  # Should be similar to CBPS package
  if (requireNamespace("CBPS")) {
    system.time(cbps <- CBPS::CBPS(W ~ X))
    wts = cbps$weights
    lhs = colSums(X[W==0, ] * wts[W==0])
    head(cbind(lhs, res$balance.condition))
  }

  # Using start values from a logistic reg can give better balance
  res2 = cbps_att(X, W,
                 theta.init = NULL,
                 balance.tol = 25)
  head(cbind(res2$balance.condition[,1], res$balance.condition))
}

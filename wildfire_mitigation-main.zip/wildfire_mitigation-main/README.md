# Wildfire Impacts and Management
Analyzing the causal impacts of wildfire mitigation strategies in California.



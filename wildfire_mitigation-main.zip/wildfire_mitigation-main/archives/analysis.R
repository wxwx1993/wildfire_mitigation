rm(list = ls())

dir = "~/Dropbox/gpw-v4-population-count-rev11_2020_30_sec_asc/processed_data"
# dir = "/scratch/users/erikcs/"

gpw_grid_ca = readRDS(file.path(dir, "gpw_grid_ca.RDS"))
FIRMS_ca_grouped = readRDS(file.path(dir, "FIRMS.RDS"))
# Create a unit identifier
FIRMS_ca_grouped$unit = paste0(FIRMS_ca_grouped$LATITUDE, FIRMS_ca_grouped$LONGITUDE)
gpw_grid_ca$unit = paste0(gpw_grid_ca$LATITUDE, gpw_grid_ca$LONGITUDE)

# m = readRDS(file.path(dir, "MatchIt.RDS")) # match object with treated.year = 2011
df.matches = readRDS(file.path(dir, "df.matches.RDS"))
#check:
# sum(unique(FIRMS_ca_grouped$unit) %in% unique(gpw_grid_ca$unit))
# length(unique(FIRMS_ca_grouped$unit)) # thats fine
# length(unique(gpw_grid_ca$unit))
# head(FIRMS_ca_grouped)


control = df.matches$unit[df.matches$treated == 0]
treated = df.matches$unit[df.matches$treated == 1]

# tmp
# control  = sample(unique(FIRMS_ca_grouped$unit), 2000)
# treated  = sample(unique(FIRMS_ca_grouped$unit[!FIRMS_ca_grouped$unit %in% control]), 2000)
# /tmp

FIRMS_ca_grouped = FIRMS_ca_grouped[FIRMS_ca_grouped$unit %in% c(control, treated), ]
FIRMS_ca_grouped$treated = 0
FIRMS_ca_grouped[FIRMS_ca_grouped$unit %in% treated, ]$treated = 1


# Create a date range panel
start.year = min(FIRMS_ca_grouped$year)
end.year = max(FIRMS_ca_grouped$year)
start.month = min(subset(FIRMS_ca_grouped, year == start.year)$month)
end.month = max(subset(FIRMS_ca_grouped, year == end.year)$month)

start.date = as.Date(paste0(start.year, "-", start.month, "-01"))
end.date = as.Date(paste0(end.year, "-", end.month, "-01"))
date.range = seq(start.date, end.date, "months")
df.date.panel = data.frame(year = as.numeric(format(date.range, "%Y")), month = as.numeric(format(date.range, "%m")), date.obj = date.range)

# Create unit-date full panel
ix.date = rep(1:nrow(df.date.panel), length(unique(FIRMS_ca_grouped$unit)))
ix.unit = gl(length(unique(FIRMS_ca_grouped$unit)), nrow(df.date.panel))
df.panel = cbind(df.date.panel[ix.date, ], unit  = unique(FIRMS_ca_grouped$unit)[ix.unit])

FIRMS_ca_grouped$has.fire = 1
df = merge(df.panel, FIRMS_ca_grouped[c("year", "month", "unit", "has.fire", "treated")], all.x = TRUE)
df$has.fire[is.na(df$has.fire)] = 0
df$treated[df$unit %in% control] = 0
df$treated[df$unit %in% treated] = 1


# df = merge(df.panel, FIRMS_ca_grouped[c("year", "month", "unit")], all.x = TRUE)
# df$has.fire = 1
# anyNA(df)
# length(unique(df$unit))

# Add treated / control identifiers
# treat.year =  2008:2015 # I don't think a single year is enough to get enough grid pts...
# Define control as unit which has zero fires in treat.year, and treated as the complement of this
# has.fire = unique(subset(df, year %in% treat.year)$unit) #unit has at least one fire in treat.year
# df.trt = data.frame(treatment = 1, unit = has.fire)
# df = merge(df, df.trt, all.x = TRUE)
# df$post.treatment.year = df$year > treat.year
# df$treatment[is.na(df$treatment)] = 0

# mean(df$treatment)
# length(has.fire) / length(unique(df$unit))

# Sample analysis, fire frequency over time and trt status
# Fire frequency by month
# df.fire.freq = aggregate(x=cbind(num.fires = df$has.fire), by = list(date.obj = df$date.obj), FUN = length) # remove, know this grp size is 4k
# df.freq = aggregate(cbind(fire.frac = df$has.fire), by = list(date.obj = df$date.obj, treatment=df$treatment), FUN = length)
# Add back to df
# df.freq = merge(df.freq, df.fire.freq)
# Fire fraction: num fires in trt/control month / total fires in month
# df.freq$fire.frac = df.freq$fire.frac / df.freq$num.fires

df.freq = aggregate(cbind(fire.frac = df$has.fire), by = list(date.obj = df$date.obj, treatment=df$treated), FUN = function(x) sum(x) / length(c(treated, control)))

pdf("Rplots.pdf")
with(subset(df.freq, treatment == 0), {
  plot(date.obj, fire.frac, type = "l", ylim = c(0, 0.1))
})
with(subset(df.freq, treatment == 1), {
  lines(date.obj, fire.frac, type = "l", col = "red")
  abline(v = "2011-01-01", col = "blue")
})

abline(v = as.Date("2011-01-01"), col = "blue")
abline(v = as.Date("2011-12-01"), col = "blue")
legend(x = "left", legend = c("control", "treated"), col = c("black", "red"), pch = 1)

# plot(df.freq$date.obj, df.freq$has.fire, type = "l")
dev.off()



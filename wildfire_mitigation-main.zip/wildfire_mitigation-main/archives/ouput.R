library(terra)
library(tidyverse)
library(data.table)
library(sf) 
library(parallel)
library(R.utils)
library(lwgeom)
library(RCurl)
library(raster)
library(tigris)
library("fst")
library(ncdf4) # package for netcdf manipulation
library(velox)

Dir = "wildfire_mitigation/raw_data/"
outDir = "wildfire_mitigation/processed_data/"
resultDir = "wildfire_mitigation/outputs/"

# plot the active fire in CA by year
firms <- readRDS(paste0(outDir, "FIRMS.RDS"))
CA_county_bound = subset(counties(cb = TRUE, resolution = "500k", year = 2020), STATEFP == "06")

for (years in 2001:2021) {
  pdf(paste0(resultDir, "bright",years, ".pdf"), height = 8, width = 6)
  plot(CA_county_bound[,13]$geometry, border="grey" , main = paste0("Avg brightness in ", years))
  plot(subset(firms, year == years)[,c("avg_BRIGHTNESS")], pch=16, cex=0.05, add = T, lengend = TRUE)
  dev.off()
}
